import React, { useState } from "react";

function App() {
  const [studentInfo, setStudentInfo] = useState({
    name: "",
    course: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudentInfo((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="App">
      <h1>Student Information</h1>
      
      {!submitted ? (
        <form onSubmit={handleSubmit}>
          <div>
            <label>
              Name:
              <input
                type="text"
                name="name"
                value={studentInfo.name}
                onChange={handleChange}
                required
              />
            </label>
          </div>
          <div>
            <label>
              Course and section:
              <input
                type="text"
                name="course and section"
                value={studentInfo.course}
                onChange={handleChange}
                required
              />
            </label>
          </div>
          <button type="submit">Submit</button>
        </form>
      ) : (
        <div>
          <h2>Submitted Information</h2>
          <p><strong>Name:</strong> {studentInfo.name}</p>
          <p><strong>Course and section:</strong> {studentInfo.course}</p>
          <button onClick={() => setSubmitted(false)}>Edit</button>
        </div>
      )}
    </div>
  );
}
export default App;
