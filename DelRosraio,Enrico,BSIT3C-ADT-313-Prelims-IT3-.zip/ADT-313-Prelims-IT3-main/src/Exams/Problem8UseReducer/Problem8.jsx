import React, { useReducer, useState, useCallback } from 'react';
import data from './problem8mock_data.json';

const initialState = {
  foods: data, 
  selected: null, 
};

const foodReducer = (state, action) => {
  switch (action.type) {
    case 'CREATE':
      return { 
        ...state,
        foods: [...state.foods, action.payload],
      };
    case 'SELECT':
      return { ...state, selected: action.payload };
    case 'EDIT':
      return {
        ...state,
        foods: state.foods.map(food =>
          food.id === action.payload.id ? { ...food, ...action.payload } : food
        ),
      };
    case 'DELETE':
      return {
        ...state,
        foods: state.foods.filter(food => food.id !== action.payload),
      };
    case 'CLEAR':
      return { ...state, selected: null }; 
    default:
      return state;
  }
};

export default function Problem8() {
  const [state, dispatch] = useReducer(foodReducer, initialState);
  const [formData, setFormData] = useState({
    food_name: '',
    price: '',
    expiration_date: '',
    calories: '',
  });

  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    const { food_name, price, expiration_date, calories } = formData;
    if (!food_name || !price || !expiration_date || !calories) return; // Ensure all fields are filled

    const newFood = {
      id: Date.now(), // Unique ID for new food
      food_name,
      price,
      expiration_date,
      calories,
    };
    dispatch({ type: 'CREATE', payload: newFood });
    setFormData({ food_name: '', price: '', expiration_date: '', calories: '' }); // Clear the form
  };

  // Handle row click to load food data into the form (Read)
  const handleRowClick = (food) => {
    setFormData({
      food_name: food.food_name,
      price: food.price,
      expiration_date: food.expiration_date,
      calories: food.calories,
    });
    dispatch({ type: 'SELECT', payload: food });
  };

  // Edit food item
  const handleEdit = () => {
    const { food_name, price, expiration_date, calories } = formData;
    if (!food_name || !price || !expiration_date || !calories) return; // Ensure all fields are filled

    const updatedFood = {
      id: state.selected.id, // Maintain the same ID
      food_name,
      price,
      expiration_date,
      calories,
    };
    dispatch({ type: 'EDIT', payload: updatedFood });
    setFormData({ food_name: '', price: '', expiration_date: '', calories: '' }); // Clear the form
  };

  // Delete food item
  const handleDelete = (id) => {
    dispatch({ type: 'DELETE', payload: id });
  };

  // Clear form
  const handleClear = () => {
    setFormData({ food_name: '', price: '', expiration_date: '', calories: '' });
    dispatch({ type: 'CLEAR' });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type='text'
            name='food_name'
            value={formData.food_name}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type='text'
            name='price'
            value={formData.price}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type='text'
            name='expiration_date'
            value={formData.expiration_date}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type='text'
            name='calories'
            value={formData.calories}
            onChange={handleChange}
          />
        </div>

        <button type='button' onClick={handleSave}>
          Save
        </button>
        <button type='button' onClick={handleClear}>
          Clear
        </button>
        {state.selected && (
          <button type='button' onClick={handleEdit}>
            Edit
          </button>
        )}
      </div>

      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {state.foods.map((food) => (
              <tr key={food.id} onClick={() => handleRowClick(food)}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => handleRowClick(food)}>
                    Edit
                  </button>
                  <button type='button' onClick={() => handleDelete(food.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
