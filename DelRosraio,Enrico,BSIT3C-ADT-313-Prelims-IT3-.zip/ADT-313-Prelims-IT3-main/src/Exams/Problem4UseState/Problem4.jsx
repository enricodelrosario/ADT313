import React, { useState } from 'react';

export default function Problem4() {

  const [formData, setFormData] = useState({
    name: '',
    yearLevel: '',
    course: 'BSCS',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form data submitted:', formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div style={{ display: 'block' }}>
        Name: 
        <input 
          type="text" 
          name="name"
          value={formData.name}
          onChange={handleInputChange}
        />
      </div>

      <div style={{ display: 'block' }}>
        <p>Year Level:</p>
        <input
          type="radio"
          id="firstYear"
          name="yearLevel"
          value="First Year"
          checked={formData.yearLevel === 'First Year'}
          onChange={handleInputChange}
        />
        <label htmlFor="firstYear">First Year</label>
        <br />

        <input
          type="radio"
          id="secondYear"
          name="yearLevel"
          value="Second Year"
          checked={formData.yearLevel === 'Second Year'}
          onChange={handleInputChange}
        />
        <label htmlFor="secondYear">Second Year</label>
        <br />

        <input
          type="radio"
          id="thirdYear"
          name="yearLevel"
          value="Third Year"
          checked={formData.yearLevel === 'Third Year'}
          onChange={handleInputChange}
        />
        <label htmlFor="thirdYear">Third Year</label>
        <br />

        <input
          type="radio"
          id="fourthYear"
          name="yearLevel"
          value="Fourth Year"
          checked={formData.yearLevel === 'Fourth Year'}
          onChange={handleInputChange}
        />
        <label htmlFor="fourthYear">Fourth Year</label>
        <br />

        <input
          type="radio"
          id="fifthYear"
          name="yearLevel"
          value="Fifth Year"
          checked={formData.yearLevel === 'Fifth Year'}
          onChange={handleInputChange}
        />
        <label htmlFor="fifthYear">Fifth Year</label>
        <br />

        <input
          type="radio"
          id="irregular"
          name="yearLevel"
          value="Irregular"
          checked={formData.yearLevel === 'Irregular'}
          onChange={handleInputChange}
        />
        <label htmlFor="irregular">Irregular</label>
        <br />
      </div>

      <div style={{ display: 'block' }}>
        Course:
        <select 
          name="course"
          value={formData.course}
          onChange={handleInputChange}
        >
          <option value="BSCS">BSCS</option>
          <option value="BSIT">BSIT</option>
          <option value="BSCpE">BSCpE</option>
          <option value="ACT">ACT</option>
        </select>
      </div>

      <div>
        <button type="submit">Submit</button>
      </div>

      <div style={{ marginTop: '20px' }}>
        <h3>Form Data:</h3>
        <pre>{JSON.stringify(formData, null, 2)}</pre>
      </div>
    </form>
  );
}
