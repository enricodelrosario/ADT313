import React, { useRef } from 'react';

function Problem3() {
  const inputRefs = Array.from({ length: 10 }, () => useRef(null));

  const focusEmptyInput = () => {
    for (let i = 0; i < inputRefs.length; i++) {
      if (inputRefs[i].current && inputRefs[i].current.value === '') {
        inputRefs[i].current.focus();
        break;
      }
    }
  };

  return (
    <>
      {Array.from({ length: 10 }, (_, index) => (
        <div key={index} style={{ display: 'block' }}>
          Input {index + 1}: <input type='text' ref={inputRefs[index]} />
        </div>
      ))}
      <button type='button' onClick={focusEmptyInput}>
        I'm a button
      </button>
    </>
  );
}

export default Problem3;
